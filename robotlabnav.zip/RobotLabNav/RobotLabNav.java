
import lejos.nxt.*;
import lejos.robotics.navigation.*;

public class RobotLabNav {

  public static void main(String[] args) {

      DifferentialPilot pilot;
      Navigator navbot;

      pilot = new DifferentialPilot(2.25f, 5.5f, Motor.A, Motor.C);
      navbot = new Navigator(pilot);

      LCD.clear();
      LCD.drawInt(50, 0, 0);
      LCD.drawInt(50, 5, 0);

      navbot.goTo(50, 50);
      navbot.waitForStop();

  }//end class main
}//end RobotLabNav
