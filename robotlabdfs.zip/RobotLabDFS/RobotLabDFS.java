
import java.util.List;
import java.util.ArrayList;
import java.util.Stack;

import lejos.nxt.*;
import lejos.robotics.navigation.*;

public class RobotLabDFS {

  public static void main(String[] args) {

    ///////////////////////////////
    // 1. Setting up the tree structure
    ///////////////////////////////

    // create new nodes e.g.
    Node S = new Node("S", 0, 0);

    // add children e.g.
    S.addChild(A);

    Node currentNode = S; //initialise currentNode to start node S
    ///////////////////////////////
    // 2. Doing DFS
    ///////////////////////////////

    Robot robot = new Robot();
    //////////////////////////////
    // 3. Making it work with a robot
    /////////////////////////////


  }//end class main
}//end RobotLabDFS
